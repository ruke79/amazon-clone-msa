package com.project.cart_service.exception;

public enum ApiStatus {
    SUCCESS,
    ERROR
}
