package com.project.cart_service.outbox;

public enum OutboxStatus {
    STARTED, COMPLETED, FAILED
}
