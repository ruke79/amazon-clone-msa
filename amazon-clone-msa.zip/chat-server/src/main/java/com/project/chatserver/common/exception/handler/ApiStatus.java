package com.project.chatserver.common.exception.handler;

public enum ApiStatus {
    SUCCESS,
    ERROR
}
