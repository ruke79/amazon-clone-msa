package com.project.chatserver.dto.response;

public class RoomMessagesResponse {

}
