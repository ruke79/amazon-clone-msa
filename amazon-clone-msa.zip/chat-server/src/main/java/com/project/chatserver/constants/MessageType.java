package com.project.chatserver.constants;

public enum MessageType {
	TEXT_ENTER,
	TEXT_TALK,
	TEXT_LEAVE,
	IMAGE
}
