package com.project.chatserver.constants;

public enum SocialType {
	GOOGLE
}
