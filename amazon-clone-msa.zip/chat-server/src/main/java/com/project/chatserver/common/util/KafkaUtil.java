package com.project.chatserver.common.util;

public class KafkaUtil {
    public static final String KAFKA_TOPIC = "chat";
    public static final String KAFKA_AGGREGATION = "aggregation";
    public static final String KAFKA_NOTIFICATION = "notification";

}
