package com.project.coupon_service.dto.request;

import com.project.coupon_service.dto.CouponDto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CouponRequest {

    private CouponDto coupon;
}
