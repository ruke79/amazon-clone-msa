package com.project.userservice.message;

public enum OutboxStatus {
    STARTED, COMPLETED, FAILED
}
