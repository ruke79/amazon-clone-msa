package com.project.userservice.security.request;


import com.project.userservice.dto.AddressDto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AddressRequest {

    private AddressDto address;
        
}
