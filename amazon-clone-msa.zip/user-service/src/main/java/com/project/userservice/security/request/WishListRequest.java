package com.project.userservice.security.request;

import lombok.Data;

@Data
public class WishListRequest {

    private String id;
    private String style;    

}
