package com.project.order_service.outbox;

public enum OutboxStatus {
    STARTED, COMPLETED, FAILED
}
