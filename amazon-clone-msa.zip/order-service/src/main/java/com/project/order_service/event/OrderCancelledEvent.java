package com.project.order_service.event;

public class OrderCancelledEvent {

}
