package com.project.order_service.domain;


public class OrderEntity extends AggregateRoot<Long> {

}
