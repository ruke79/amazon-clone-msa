rootProject.name = "gateway-server"
