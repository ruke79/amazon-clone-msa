module.exports = {
    twin: {
        preset: 'styled-components',
    },
}