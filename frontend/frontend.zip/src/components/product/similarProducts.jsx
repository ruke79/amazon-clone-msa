export const similarProducts = [   
    
]