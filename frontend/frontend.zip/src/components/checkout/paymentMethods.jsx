export const paymentMethods = [
    {
        name: "Paypal",
        id: "paypal",
        description: "If you don't have a paypal account, you can also pay via paypal with your creadit card or bank devit card.",
        images: [],
    },
    {
        name: "Creadit cart",
        id: "credit_card",
        description: "",
        images: [
            "visa",
            "mastedcard",
            "paypal",
            "maestro",
            "american_express",
            "cb",
            "jcb",
        ],
    },
    {
        name: "Cash",
        id: "cash",
        description: "If you don't have a paypal account, you can also pay via paypal with your creadit card or bank devit card.",
        images: [],
    },
]